## Minigames .SC2 maps

DefeatZealotsBlink . Made by 4chron

HallucinIce and FlowerFields. Made by SoyGema 

PredictBattleOutcome and Marine_Rescue . Made by Deadzombie2333 (changed initialization random army playable spaces)

DefeatRavagersRepairCyclones. Made by by TitanEX1 (changed bug initializing by point ) 

HitAndRun . Made by emre erdemoglu and Holyswamp 

MineralsHaveArrived. Made by ShawdowSpyes (changed terrain, camera inizialization  )
